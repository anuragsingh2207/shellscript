#!/bin/bash

echo "Content-type: text/html"
echo

cat<<ABc
<html>
<head>
<title>Sample_Title</title>
<body>
<h1><font color="blue">CPU Load Balance</h1></font>
<font color="red"><h2>`uptime`
</body>
</head>
</html>
ABc
