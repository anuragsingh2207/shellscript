#!/bin/sh
echo "Content-type: text/html\n"
#echo "<html><body><h2>Hello world</h2><br><font color="red"><h1>Linux BASH CGI-SCRIPT</h1></font></body></html>"

cat<<ABC
<html>
<body>
<h1> CPU LOAD BALANCE </h1>
<br>
<font color="red"><h2>`uptime`</h2></font>
</br>
</body>
</html>
ABC

