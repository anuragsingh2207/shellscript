#!/bin/bash
echo -e "Content-type: text/html\n"
vmstatus(){
echo "<html>"
echo "<head>"
echo "<title> VMREPORT </title>"
echo "<body>"
echo "<h1> Current Virtual Memory Status </h1>"
echo "<font color=red>"
echo "<p><h1>`vmstat`</h1></p>"
echo "</font>"
echo "<br>"
echo "</body>"
echo "</html>"
}

vmstatus
sleep 3
echo "<h1>End of the line</h1>"
