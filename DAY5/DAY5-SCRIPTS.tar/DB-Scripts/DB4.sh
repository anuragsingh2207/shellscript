#myvar=$(mysql DEMO -u root -pPASSWD<<<"select *from demo_table")

# MySQL expects passwords to be entered through the command line (with no space between the option and value)
dbname=DEMO
source=$(mysql -uroot -pPASSWD -e "use $dbname;show tables;")
echo "Source:"
echo $source
table=$(echo $source|sed "s/Tables_in_$dbname//g")

echo $table
<<AB
for tb in demo_table 
do
	mysql -u root -pPASSWD -e "use $dbname;\
	select * into outfile './${tb}.csv"\
	fields terminated by ','\
	lines terminated by '\n'\
	from $tb"\
done
AB
