
# mysql -u root -p'PASSWD' use DEMO;
# mysql -u root -p'PASSWD' show tables;
# mysql -u root -p'PASSWD' select *from demo_table ;
v=`mysql -u root -p'PASSWD'<<ABC
 use DEMO;
 show tables;
 select *from demo_table;
ABC`

if [ -z "$v" ];then
	echo "there is no record from DEMO db"
else
	echo "$v"|awk '{OFS="\t";print $1,$NF}'
fi



