<<ABCD
myvar=$(mysql -u root -p'PASSWD'  <<ABC
        use DEMO;
        select name,email from demo_table where name='karthik';
ABC
)
echo "$myvar"
ABCD

# mysql -u root -p'PASSWD' use DEMO;
# mysql -u root -p'PASSWD' show tables;
# mysql -u root -p'PASSWD' select *from demo_table ;
ID=320
name="X-DABC"
Email="X-DABC@GMAIL.COM"
mysql -u root -p'PASSWD'<<ABC
 use DEMO;
 show tables;
 insert into demo_table (id,name,email)values("$ID","$name","$Email");
 select *from demo_table;
ABC



