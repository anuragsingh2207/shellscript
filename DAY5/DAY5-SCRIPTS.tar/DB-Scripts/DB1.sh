
# mysql -u root -p'PASSWD' use DEMO;
# mysql -u root -p'PASSWD' show tables;
# mysql -u root -p'PASSWD' select *from demo_table ;
mysql -u root -p'PASSWD'<<ABC
 use DEMO;
 show tables;
 select *from demo_table;
ABC



