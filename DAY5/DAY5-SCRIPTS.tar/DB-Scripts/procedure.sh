
#!/usr/bin/ksh
oraclelogon=$1;
sqlplus $oraclelogon <<EOF
whenever sqlerror exit 1
SET SERVEROUTPUT ON
begin
  dbms_output.put_line ('running procedure');
  proc1;
  dbms_output.put_line('procedure completed');
end;
/
exit
EOF
# sh shellscriptrun.sh username/password@dbname > log.txt
