read -p "Enter a student name:" name

read -p "Enter $name sub1 mark:" s1
read -p "Enter $name sub2 mark:" s2
read -p "Enter $name sub3 mark:" s3

total=`expr $s1 + $s2 + $s3` # total=$((s1+s2+s3))

avg=`echo "scale=2;$total/3"|bc`

echo "
------------------------------
Name: $name
------------------------------
Sub1:$s1
Sub2:$s2
Sub3:$s3
------------------------------
Total:$total
------------------------------
Avg:$avg
-------------------------------"

