read -p "Enter a command:" cmd

$cmd 1>>result.log 2>>/var/log/error.log
