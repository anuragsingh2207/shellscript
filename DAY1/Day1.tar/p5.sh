
name=`whoami`
count=`ps -e|wc -l`

echo -e "Login name:$name\nTotal no.of process count:$count"
echo # empty line
echo -e "Login name:$name\t\tTotal no.of process count:$count"
echo # empty line
echo -e "Login name:$name\t----\n
Total no.of process count:$count"
