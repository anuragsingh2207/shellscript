
echo "Login shell name:$SHELL"
echo "Login path:$HOME"
echo "Current working directory:$PWD"

v=$SHELL
echo "v value is:$v"
