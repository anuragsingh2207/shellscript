Fname="/etc/passwd"
echo "About $Fname file details:-"
echo "------------------------------------"
ls -l $Fname
echo "-------------------------------------"
