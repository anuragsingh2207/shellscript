
read -p "enter a server name:" server

if [ $server == unix ];then
	echo "matched(1)"
elif [ $server == linux -o $server == LINUX ];then
	echo "matched(2)"
elif [ $server == winx ];then
	echo "matched(3)"
else
	echo "not-matched"
fi
echo # empty line

case $server in
unix)	echo "MATCHED(1)" 
	;;
linux|LINUX)  echo "MATCHED(2)" ;;
winx)   echo "MATCHED(3)" ;;
1|3.45|A|a) echo "MATCHED(4)" ;;
*)	echo "NOT-MATCHED"
esac 
