read -p "Enter a search pattern from /etc/passwd:" key
grep $key /etc/passwd
if [ $? -ne 0 ];then
	echo "Sorry pattern $key is not matched from /etc/password file"
fi

