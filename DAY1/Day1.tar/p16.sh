
 read -p "Enter a shell name:" var
 if [ $var == "bash" ];then
	profile="~/.bashrc"
 elif [ $var == "sh" ];then
	profile="~/.profile"
 elif [ $var == "ksh" ];then
	profile="~/.kshrc" 
 else
	echo "Sorry $var is not matched"
	var="/bin/nologin"
	profile="/etc/profile"
 fi
 echo -e "SHELL NAME:$var\t PROFILE:$profile"

