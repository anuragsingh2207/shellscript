
read -p "Enter a user name:" name

if [ $name == "admin" -o $name == "ADMIN" ]
then
	read -p "Enter a port number:" pno
	if [ $pno -gt 500 -a $pno -lt 600 ]
	then
		echo -e "user name:$name\t Port number:$pno"
	else
		echo "Invalid port number range"
	fi
else
	echo "Invalid user name"
fi
