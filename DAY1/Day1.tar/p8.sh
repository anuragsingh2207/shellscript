<<abc
ename="Mr.Ram kumar shiv"
eid=123
edept=sales # edept="sales"
ecost=1345.79
abc

read -p "Enter a emp name:" ename
read -p "Enter $ename emp ID:" eid
read -p "Enter $ename working dept:" edept 
read -p "Enter $ename basic pay:" ecost

echo "Emp name:$ename
------------------------
$ename  EMP ID:$eid
------------------------
$ename Working department:$edept
------------------------
Cost:$ecost
------------------------"

