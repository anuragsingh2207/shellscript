<<abc
ename="Mr.Ram kumar shiv"
eid=123
edept=sales # edept="sales"
ecost=1345.79
abc

echo "Enter a emp name:"
read ename
echo -n "Enter $ename emp ID:"
read eid
echo -n "Enter $ename working dept:"
read edept
echo "Enter $ename basic pay:"
read ecost

echo "Emp name:$ename
------------------------
$ename  EMP ID:$eid
------------------------
$ename Working department:$edept
------------------------
Cost:$ecost
------------------------"

