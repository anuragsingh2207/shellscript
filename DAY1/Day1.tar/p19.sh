
grep tcsh /etc/passwd
if [ $? -ne 0 ];then
	echo "Sorry pattern tcsh is not matched from /etc/password file"
fi

