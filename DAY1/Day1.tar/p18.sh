
if [ `whoami` == "root" ];then # if [ $UID -eq 0 ] # if [ `id -u` -eq 0 ] # if [ `id -un` == "root" ]
	echo "Login is success"
	# yum install package
	# ....
else
	echo "Sorry your not root user"
fi


