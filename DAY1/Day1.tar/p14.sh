
read -p "Enter a N value:" n

if [ $n -gt 500 ]
then
	echo "True block"
	t=`expr $n + 100`
	echo "T value:$t"
else
	echo "False block"
	t=`expr $n - 100`
	echo "T value:$t"
fi

