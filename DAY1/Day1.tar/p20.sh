
grep bash /etc/passwd
if [ $? -ne 0 ];then
	echo "Sorry pattern bash is not matched from /etc/password file"
fi

