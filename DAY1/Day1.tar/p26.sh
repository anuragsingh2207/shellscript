if [ `whoami` == "root" ]
then
	read -p "Enter a server name:" sname
	case $sname in
	unix)	echo "Current process:-"
		ps -f
		;;
	linux|Linux|LINUX) echo "Version:`uname -r`" ;;
	winx)	if [ `ps -e|wc -l` -gt 150 ];then
			read -p "Enter a shell name:" var
			case $var in
			bash)  echo ".bashrc initialized" ;;
			sh)    echo ".profile initialized" ;;
			*)	echo "Invalid shell" 
			esac
		else
			echo "Less than 150 process is running"
		fi
		;;
	*)	echo "Invalid server name"
	esac
else
	echo "Sorry your not root user"
fi
