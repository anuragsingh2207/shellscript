ename="Mr.Ram kumar shiv"
eid=123
edept=sales # edept="sales"
ecost=1345.79

echo "Emp name:$ename"
echo "$ename  EMP ID:$eid"
echo "$ename Working department:$edept"
echo "Cost:$ecost"

