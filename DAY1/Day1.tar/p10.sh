


read -p "Enter a disk name:" d1
read -p "Enter a $d1 partition size:" ds1


read -p "Enter a disk name:" d2
read -p "Enter a $d2 partition size:" ds2

read -p "Enter a disk name:" d3
read -p "Enter a $d3 partition size:" ds3

total=`expr $ds1 + $ds2 + $ds3` # total=$((ds1+ds2+ds3))

echo -e "
----------------------------------------------
Disk:$d1\t  Size:$ds1
Disk:$d2\t  Size:$ds2
Disk:$d3\t  Size:$ds3
---------------------------------------------
Total Partition Size:$total
---------------------------------------------"
