read -p "Enter a user name:" name

if [ $name == "admin" ]
then
	read -p "Enter a shell name:" var
	if [ $var == "bash" ];then
		echo "input shell name is:$var"
		echo "$var version is:$BASH_VERSION"
	else
		echo "Sorry $var is not matched"
	fi
else
	echo "Sorry your not admin"
fi
