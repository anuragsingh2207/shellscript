#Fname="/etc/passwd"

echo "Enter a file name:" ## STDOUT
read Fname ## interface to keyboard

echo "About $Fname file details:-"
echo "------------------------------------"
ls -l $Fname
echo "-------------------------------------"
