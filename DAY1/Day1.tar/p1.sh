# variable 
# -----------
# what is variable - namespace - its holding the value
#						 ------//cmd,cmdresult,0-9,A-Za-z,space,words,specicalchar etc., 
#
# Syntax:-
# ---------
# variable=value
# |
# |____starts with a-z A-Z _ (not starts with digits,space,specialchar) 
#
# |___ There is no space in = LHS,RHS
#
#
#  var=100	----> var | 100 |0x3555

var=100
name="root"
Fname="/etc/passwd"
IP="127.0.0.1"
v="date"
result="`date +%D`"

# $var=100
# var =100
# var= 200
# 5var=100
# ---------------//Invalid 
# var5=134 -->valid
#
echo "var value :$var"
echo "Login name:$name"
echo "File name:$Fname"
ls -l $Fname 
echo "IP Address:$IP"
echo "v value:$v"
echo "Today:$result"
