PORT=80
Fname="/var/log/repo.log"
DEVICE="/dev/xvdb"

Finfo(){
	echo "File name:$Fname
	-------------------------
	PORT:$PORT
	-------------------------
	DEVICE:$DEVICE
	-------------------------"
}
