source ./a1.sh
echo $PORT
