f1(){
echo "A.$#"
}

f2(){
     echo "B.$#"
 }
 echo "C.$#"
 f1 A B C D
 f2 $@ 1 2
