echo "This is $0 script file"
. /root/SH/a1.sh
Finfo

